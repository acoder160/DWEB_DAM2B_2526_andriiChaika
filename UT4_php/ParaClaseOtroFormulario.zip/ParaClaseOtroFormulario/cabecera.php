﻿<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Primeros ejemplos con PHP</title>
        <link rel="stylesheet" type="text/css" href="css/estilo.css" />
    </head>

    <!-- el cuerpo  -->
    <body>
    <div id="contenido">
        <div id="cabecera">
            <h1>Otro ejercicio de Formularios y PHP</h1>           
        </div> <!-- fin de cabecera -->
        <div id="principal">
              
           