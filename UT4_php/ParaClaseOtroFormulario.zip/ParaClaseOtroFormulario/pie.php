﻿
</div>     <!-- fin de principal-->
    <div id="pie">
            <p class="copyright">
                &copy; <?php echo date("Y"); ?> Ejercicios  de PHP
            </p>
     </div>
    </div><!-- fin de contenido -->
    </body>
</html>
