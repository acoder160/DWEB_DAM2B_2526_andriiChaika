<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Document</title>
</head>
<body>
    <header>
        <h1>Club Deportivo CIMAS</h1>
    <nav>
        <ul>
            <li><a href="index.php?page=principal">Inicio</a></li>
                <li><a href="index.php?page=registro">Registro</a></li>
                <li><a href="index.php?page=deportistas">Deportistas</a></li>
                <li><a href="index.php?page=logout">Cerrar sesión</a></li>
        </ul>
    </nav>

</header>