  <main>
    <h1>Bienvenidos al Club Deportivo CIMAS</h1>
    <p>Únete a nuestro club y disfruta de nuestras instalaciones y actividades deportivas</p>

    </main>
