</main>
<footer>
    <p>© 2025 Club Deportivo CIMAS</p>
</footer>
    
</body>
</html>