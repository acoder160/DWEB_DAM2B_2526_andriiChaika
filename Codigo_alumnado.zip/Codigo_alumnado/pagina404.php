<h2>Página no encontrada</h2>
<p>Lo sentimos, la página que buscas no existe.</p>
<a href="index.php">Volver al inicio</a>